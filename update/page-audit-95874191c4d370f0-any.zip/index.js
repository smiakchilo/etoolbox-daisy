// src/addons/page-audit/evidence.ts
var MAX_COLUMNS = 20;
var MAX_LABEL_LENGTH = 60;
var MAX_CELL_LENGTH = 2e3;
var SUB_ITEMS_COLUMN_KEY = "evidence-sub-items";
var SUB_ITEMS_COLUMN_LABEL = "Sub items";
function isRecord(value) {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}
function asArray(value) {
  return Array.isArray(value) ? value : void 0;
}
function asText(value) {
  if (typeof value === "string") return value.trim() === "" ? void 0 : value;
  if (typeof value === "number") return Number.isFinite(value) ? String(value) : void 0;
  if (typeof value === "boolean") return value ? "yes" : "no";
  if (!isRecord(value)) return void 0;
  return asText(value["value"]) ?? asText(value["displayString"]) ?? asText(value["text"]);
}
function unique(parts) {
  const seen = /* @__PURE__ */ new Set();
  const kept = [];
  for (const part of parts) {
    if (part === void 0 || part === "") continue;
    if (seen.has(part)) continue;
    seen.add(part);
    kept.push(part);
  }
  return kept;
}
function humanBytes(value) {
  const absolute = Math.abs(value);
  if (absolute < 1024) return `${String(Math.round(value))} B`;
  if (absolute < 1024 * 1024) return `${(value / 1024).toFixed(1)} KB`;
  return `${(value / (1024 * 1024)).toFixed(1)} MB`;
}
function formatNumber(value, valueType, displayUnit) {
  if (valueType === "bytes") return humanBytes(value);
  if (valueType === "ms" || valueType === "timespanMs") return `${String(Math.round(value))} ms`;
  const unit = displayUnit?.trim();
  if (unit === void 0 || unit === "") return String(value);
  return unit === "%" ? `${String(value)}%` : `${String(value)} ${unit}`;
}
function cellText(text) {
  return text.length <= MAX_CELL_LENGTH ? text : `${text.slice(0, MAX_CELL_LENGTH - 1)}\u2026`;
}
function sourceLocationText(value) {
  const url = asText(value["url"]);
  const line = value["line"];
  const column = value["column"];
  const location = url === void 0 ? void 0 : typeof line !== "number" ? url : typeof column === "number" ? `${url}:${String(line + 1)}:${String(column)}` : `${url}:${String(line + 1)}`;
  const original = isRecord(value["original"]) ? value["original"] : void 0;
  const file = original === void 0 ? void 0 : asText(original["file"]) ?? "(unmapped)";
  const originalLine = original?.["line"];
  const originalColumn = original?.["column"];
  const mapped = file === void 0 ? void 0 : typeof originalLine !== "number" ? file : typeof originalColumn === "number" ? `${file}:${String(originalLine + 1)}:${String(originalColumn)}` : `${file}:${String(originalLine + 1)}`;
  if (location === void 0) return mapped ?? "";
  return mapped === void 0 ? location : `${location} (source-mapped from ${mapped})`;
}
function linkText(value) {
  const text = asText(value["text"]);
  const url = asText(value["url"]);
  if (text === void 0) return url ?? "";
  return url === void 0 || url === text ? text : `${text} (${url})`;
}
function isEmptyCell(cell) {
  switch (cell.kind) {
    case "text":
      return cell.value === "";
    case "selector":
      return cell.selector === "" && (cell.snippet ?? "") === "" && (cell.label ?? "") === "";
    case "list":
      return cell.items.length === 0;
  }
}
function textOfCell(cell) {
  switch (cell.kind) {
    case "text":
      return cell.value;
    case "selector":
      return unique([cell.label, cell.selector, cell.snippet, cell.explanation]).join(" \u2014 ");
    case "list":
      return cell.items.map(textOfCell).filter((part) => part !== "").join("; ");
  }
}
function selectorCell(value) {
  const selector = asText(value["selector"]);
  const snippet = asText(value["snippet"]);
  const label = asText(value["nodeLabel"]);
  const explanation = asText(value["explanation"]);
  if (selector === void 0) {
    const text = unique([label, snippet, explanation]).join(" \u2014 ");
    return { kind: "text", value: cellText(text) };
  }
  return {
    kind: "selector",
    selector,
    ...snippet === void 0 ? {} : { snippet: cellText(snippet) },
    ...label === void 0 ? {} : { label },
    ...explanation === void 0 ? {} : { explanation: cellText(explanation) }
  };
}
function formatCell(value, valueType, displayUnit) {
  if (value === void 0 || value === null) return { kind: "text", value: "" };
  if (typeof value === "string") {
    return value.startsWith("data:image/") ? { kind: "text", value: "" } : { kind: "text", value: cellText(value) };
  }
  if (typeof value === "number") {
    return { kind: "text", value: formatNumber(value, valueType, displayUnit) };
  }
  if (typeof value === "boolean") return { kind: "text", value: value ? "yes" : "no" };
  const array = asArray(value);
  if (array !== void 0) {
    return {
      kind: "text",
      value: cellText(
        array.map((entry) => textOfCell(formatCell(entry, valueType, displayUnit))).filter((part) => part !== "").join("; ")
      )
    };
  }
  if (!isRecord(value)) {
    try {
      return { kind: "text", value: cellText(JSON.stringify(value) ?? "") };
    } catch {
      return { kind: "text", value: "" };
    }
  }
  switch (asText(value["type"])) {
    case "node":
      return selectorCell(value);
    case "source-location":
      return { kind: "text", value: cellText(sourceLocationText(value)) };
    case "link":
      return { kind: "text", value: cellText(linkText(value)) };
    case "url":
    case "code":
    case "text":
      return { kind: "text", value: cellText(asText(value["value"]) ?? "") };
    case "numeric":
      return typeof value["value"] === "number" ? { kind: "text", value: formatNumber(value["value"], valueType, displayUnit) } : { kind: "text", value: "" };
    case "baseline-status":
      return {
        kind: "text",
        value: cellText(asText(value["displayString"]) ?? asText(value["status"]) ?? "")
      };
    case "subitems": {
      const items = asArray(value["items"]) ?? [];
      const cells = items.map((entry) => formatCell(entry, valueType, displayUnit)).filter((cell) => !isEmptyCell(cell));
      return { kind: "list", items: cells };
    }
    default: {
      const direct = asText(value);
      if (direct !== void 0) return { kind: "text", value: cellText(direct) };
      try {
        return { kind: "text", value: cellText(JSON.stringify(value)) };
      } catch {
        return { kind: "text", value: "" };
      }
    }
  }
}
function columnLabel(heading, fallbackKey) {
  const label = asText(heading.label) ?? fallbackKey;
  return label.length <= MAX_LABEL_LENGTH ? label : `${label.slice(0, MAX_LABEL_LENGTH - 1)}\u2026`;
}
function subItemsCell(record, headings) {
  const raw = record["subItems"];
  const items = isRecord(raw) ? asArray(raw["items"]) : asArray(raw);
  if (items === void 0 || items.length === 0) return void 0;
  const cells = items.flatMap((item) => {
    const sub = isRecord(item) ? item : void 0;
    let text;
    if (sub === void 0) {
      text = textOfCell(formatCell(item));
    } else {
      const values = headings.flatMap((heading) => {
        const subHeading = heading.subItemsHeading;
        if (subHeading?.key === void 0) return [];
        return textOfCell(formatCell(sub[subHeading.key], subHeading.valueType));
      });
      text = values.length === 0 ? textOfCell(formatCell(item)) : unique(values).join(" \u2014 ");
    }
    return text === "" ? [] : [{ kind: "text", value: cellText(text) }];
  });
  const kept = cells.filter((cell) => !isEmptyCell(cell));
  return kept.length === 0 ? void 0 : { kind: "list", items: kept };
}
function readHeadings(headings) {
  return (asArray(headings) ?? []).filter(isRecord);
}
function keyedHeadings(headings) {
  return headings.filter(
    (heading) => typeof heading.key === "string" && heading.key !== ""
  );
}
function tableBlock(headings, items) {
  const all = readHeadings(headings);
  const keyed = keyedHeadings(all);
  const records = (asArray(items) ?? []).filter(isRecord);
  if (keyed.length === 0 || records.length === 0) return void 0;
  const columns = [];
  const byKey = /* @__PURE__ */ new Map();
  for (const heading of keyed) {
    if (byKey.has(heading.key) || columns.length >= MAX_COLUMNS) continue;
    byKey.set(heading.key, heading);
    columns.push({ key: heading.key, label: columnLabel(heading, heading.key) });
  }
  const subItems = records.map((record) => subItemsCell(record, all));
  const hasSubItems = subItems.some((cell) => cell !== void 0);
  const rows = records.map((record, index) => {
    const row = [];
    for (const column of columns) {
      const heading = byKey.get(column.key);
      row.push(formatCell(record[column.key], heading?.valueType, heading?.displayUnit));
    }
    if (hasSubItems) row.push(subItems[index] ?? { kind: "text", value: "" });
    return row;
  });
  return {
    kind: "table",
    columns: hasSubItems ? [...columns, { key: SUB_ITEMS_COLUMN_KEY, label: SUB_ITEMS_COLUMN_LABEL }] : columns,
    rows
  };
}
function listSections(items) {
  return (asArray(items) ?? []).flatMap((item) => {
    if (!isRecord(item)) return [{ title: void 0, value: item }];
    if (item["type"] !== "list-section") return [{ title: void 0, value: item }];
    return [
      {
        title: asText(item["title"]) ?? asText(item["description"]),
        value: item["value"]
      }
    ];
  });
}
function checklistBlock(items) {
  if (!isRecord(items)) return void 0;
  const entries = [];
  for (const [key, entry] of Object.entries(items)) {
    const item = isRecord(entry) ? entry : void 0;
    const label = asText(item?.["label"]) ?? key;
    const value = item?.["value"];
    entries.push({
      label,
      value: typeof value === "boolean" ? value ? "yes" : "no" : textOfCell(formatCell(value))
    });
  }
  if (entries.length === 0) return void 0;
  return { kind: "checklist", items: entries };
}
function networkTreeBlock(value) {
  const chains = isRecord(value["chains"]) ? value["chains"] : void 0;
  if (chains === void 0) return void 0;
  const roots = buildTreeNodes(chains);
  if (roots.length === 0) return void 0;
  return { kind: "tree", roots };
}
function buildTreeNodes(chains) {
  const nodes = [];
  for (const entry of Object.values(chains)) {
    if (!isRecord(entry)) continue;
    const url = asText(entry["url"]);
    if (url === void 0) continue;
    const duration = entry["navStartToEndTime"];
    const bytes = entry["transferSize"];
    nodes.push({
      url,
      ...typeof duration === "number" ? { durationMs: duration } : {},
      ...typeof bytes === "number" ? { transferBytes: bytes } : {},
      ...entry["isLongest"] === true ? { isLongest: true } : {},
      children: isRecord(entry["children"]) ? buildTreeNodes(entry["children"]) : []
    });
  }
  return nodes;
}
function nodeBlock(value) {
  const cell = selectorCell(value);
  if (cell.kind !== "selector") {
    return { kind: "node", explanation: textOfCell(cell) };
  }
  return {
    kind: "node",
    ...cell.label === void 0 ? {} : { label: cell.label },
    selector: cell.selector,
    ...cell.snippet === void 0 ? {} : { snippet: cell.snippet },
    ...cell.explanation === void 0 ? {} : { explanation: cell.explanation }
  };
}
function titledBlock(block, title) {
  if (title === void 0) return block;
  if (block.kind === "table") return { ...block, title };
  if (block.kind === "tree") return { ...block, title };
  if (block.kind === "checklist" || block.kind === "node") return block;
  return { ...block, value: `${title} \u2014 ${block.value}` };
}
function listBlocks(items) {
  const sections = listSections(items);
  if (sections.length === 0) return void 0;
  const blocks = [];
  for (const section of sections) {
    const value = isRecord(section.value) ? section.value : void 0;
    if (value === void 0) {
      const cell2 = formatCell(section.value);
      const text2 = section.title === void 0 ? textOfCell(cell2) : unique([section.title, textOfCell(cell2)]).join(" \u2014 ");
      if (text2 !== "") blocks.push({ kind: "text", value: cellText(text2) });
      continue;
    }
    const type = asText(value["type"]);
    if (type === "table" || type === "opportunity" || type === void 0 && value["headings"] !== void 0) {
      const table = tableBlock(value["headings"], value["items"]);
      if (table !== void 0) blocks.push(titledBlock(table, section.title));
      continue;
    }
    if (type === "checklist") {
      const checklist = checklistBlock(value["items"]);
      if (checklist !== void 0) blocks.push(titledBlock(checklist, section.title));
      continue;
    }
    if (type === "network-tree") {
      const tree = networkTreeBlock(value);
      if (tree !== void 0) blocks.push(titledBlock(tree, section.title));
      continue;
    }
    if (type === "node") {
      const node = nodeBlock(value);
      blocks.push(
        section.title === void 0 ? node : { ...node, label: unique([section.title, node.label]).join(" \u2014 ") }
      );
      continue;
    }
    const cell = formatCell(value);
    const text = section.title === void 0 ? textOfCell(cell) : unique([section.title, textOfCell(cell)]).join(" \u2014 ");
    if (text !== "") blocks.push({ kind: "text", value: cellText(text) });
  }
  return blocks.length === 0 ? void 0 : blocks;
}
function describeProblem(audit) {
  const description = asText(audit.description)?.replace(/\[([^\]]+)]\(([^)\s]+)\)/g, "$1 ($2)");
  return description ?? asText(audit.title) ?? "This audit did not pass";
}
function hasMeasuredSaving(audit) {
  const savings = audit.metricSavings;
  if (isRecord(savings) && Object.values(savings).some(
    (value) => typeof value === "number" && Number.isFinite(value) && value > 0
  )) {
    return true;
  }
  const debugData = audit.details?.debugData;
  return isRecord(debugData) && typeof debugData["wastedBytes"] === "number" && debugData["wastedBytes"] > 0;
}
function auditEvidence(audit) {
  const details = audit.details;
  if (details !== void 0) {
    const blocks = (details.type === "table" || details.type === "opportunity" || details.type === void 0 && details.headings !== void 0 ? (() => {
      const table = tableBlock(details.headings, details.items);
      return table === void 0 ? void 0 : [table];
    })() : void 0) ?? (details.type === "list" ? listBlocks(details.items) : void 0) ?? (details.type === "checklist" ? (() => {
      const checklist = checklistBlock(details.items);
      return checklist === void 0 ? void 0 : [checklist];
    })() : void 0);
    if (blocks !== void 0) return blocks;
  }
  return [{ kind: "text", value: cellText(describeProblem(audit)) }];
}

// src/addons/page-audit/pageAuditTransport.ts
var ROOT_SESSION = "DAISY_ROOT_SESSION";
var TARGET_ID = "DAISY_AUDIT_TARGET";
var METHOD_NOT_FOUND = -32601;
var COMMAND_FAILED = -32e3;
var DebuggerTransport = class {
  constructor(debuggerApi, target) {
    this.debuggerApi = debuggerApi;
    this.targetInfo = {
      targetId: TARGET_ID,
      type: "page",
      title: target.title,
      url: target.url,
      attached: false,
      canAccessOpener: false
    };
    debuggerApi.attach("1.3");
    debuggerApi.on("message", this.forward);
  }
  onmessage;
  onclose;
  closed = false;
  targetInfo;
  forward = (_event, method, params, sessionId) => {
    this.emit({ method, params, sessionId: sessionId || ROOT_SESSION });
  };
  send(raw) {
    if (this.closed) return;
    let message;
    try {
      message = JSON.parse(raw);
    } catch {
      return;
    }
    const { id, method, params, sessionId } = message;
    if (id === void 0 || method === void 0) return;
    if (sessionId === void 0) {
      this.answerBrowserCommand(id, method);
      return;
    }
    this.debuggerApi.sendCommand(method, params ?? {}, sessionId === ROOT_SESSION ? void 0 : sessionId).then(
      (result) => this.reply(id, result, sessionId),
      (error) => this.emit({
        id,
        error: {
          code: COMMAND_FAILED,
          message: error instanceof Error ? error.message : String(error)
        },
        sessionId
      })
    );
  }
  close() {
    if (this.closed) return;
    this.closed = true;
    this.debuggerApi.removeListener("message", this.forward);
    try {
      this.debuggerApi.detach();
    } catch {
    }
    this.onclose?.();
  }
  answerBrowserCommand(id, method) {
    switch (method) {
      case "Target.getBrowserContexts":
        this.reply(id, { browserContextIds: [] });
        return;
      case "Target.setDiscoverTargets":
        this.reply(id, {});
        this.emit({ method: "Target.targetCreated", params: { targetInfo: this.targetInfo } });
        return;
      case "Target.setAutoAttach":
        this.reply(id, {});
        this.emit({
          method: "Target.attachedToTarget",
          params: {
            sessionId: ROOT_SESSION,
            targetInfo: { ...this.targetInfo, attached: true },
            waitingForDebugger: false
          }
        });
        return;
      case "Target.attachToTarget":
        this.reply(id, { sessionId: ROOT_SESSION });
        return;
      case "Target.getTargetInfo":
        this.reply(id, { targetInfo: this.targetInfo });
        return;
      case "Target.getTargets":
        this.reply(id, { targetInfos: [this.targetInfo] });
        return;
      default:
        this.emit({ id, error: { code: METHOD_NOT_FOUND, message: `Unsupported ${method}` } });
    }
  }
  reply(id, result, sessionId) {
    this.emit({ id, result: result ?? {}, ...sessionId === void 0 ? {} : { sessionId } });
  }
  emit(message) {
    setImmediate(() => {
      if (!this.closed) this.onmessage?.(JSON.stringify(message));
    });
  }
};

// src/addons/page-audit/pageAudit.ts
var PAGE_AUDIT_TIMEOUT_MS = 12e4;
var PAGE_AUDIT_MAX_QUEUED = 2;
var PAGE_LOAD_TIMEOUT_MS = 3e4;
var WINDOW_WIDTH = 1280;
var WINDOW_HEIGHT = 800;
var UNSCORED_MODES = /* @__PURE__ */ new Set(["informative", "manual", "notApplicable", "error"]);
function parseTarget(raw, currentUrl) {
  const value = raw?.trim();
  let candidate;
  try {
    if (value === void 0 || value === "") {
      if (currentUrl === void 0) return "no_page";
      candidate = new URL(currentUrl);
    } else if (/^\/(?!\/)/.test(value)) {
      if (currentUrl === void 0) return "no_page";
      candidate = new URL(value, new URL(currentUrl).origin);
    } else {
      candidate = new URL(value);
    }
  } catch {
    return void 0;
  }
  if (candidate.protocol !== "http:" && candidate.protocol !== "https:") return void 0;
  if (candidate.username !== "" || candidate.password !== "") return void 0;
  candidate.hash = "";
  return candidate;
}
function lighthouseFailures(lhr, categories) {
  const seen = /* @__PURE__ */ new Set();
  const failures = [];
  for (const category of categories) {
    const refs = [...lhr.categories[category]?.auditRefs ?? []].sort(
      (a, b) => b.weight - a.weight
    );
    for (const ref of refs) {
      const audit = lhr.audits[ref.id];
      if (audit === void 0 || seen.has(ref.id)) continue;
      if (UNSCORED_MODES.has(audit.scoreDisplayMode)) {
        if (audit.scoreDisplayMode !== "informative" || !hasMeasuredSaving(audit)) continue;
      } else if (audit.score === null || audit.score >= 1) {
        continue;
      }
      seen.add(ref.id);
      failures.push({
        category,
        id: ref.id,
        title: audit.title,
        score: audit.score,
        ...audit.displayValue === void 0 || audit.displayValue === "" ? {} : { displayValue: audit.displayValue },
        evidence: auditEvidence(audit)
      });
    }
  }
  return failures;
}
async function inspectAuditRequest(address, deps) {
  let url;
  try {
    url = new URL(address);
  } catch {
    return { allowed: false, reason: "it is not a valid address" };
  }
  if (url.protocol === "data:" || url.protocol === "blob:" || url.protocol === "about:") {
    return { allowed: true };
  }
  if (deps.isConfiguredOrigin(url.origin)) return { allowed: true };
  const target = await deps.inspectTarget(url);
  return target.allowed ? { allowed: true } : { allowed: false, reason: "it is a local or internal address" };
}
function sleepUntilAborted(signal) {
  return new Promise((resolve) => {
    if (signal === void 0) return;
    if (signal.aborted) resolve("cancelled");
    else signal.addEventListener("abort", () => resolve("cancelled"), { once: true });
  });
}
function shortUrl(url) {
  return url.length <= 200 ? url : `${url.slice(0, 197)}...`;
}
function createPageAudit(deps) {
  const timeoutMs = deps.timeoutMs ?? PAGE_AUDIT_TIMEOUT_MS;
  let queue = Promise.resolve();
  let accepted = 0;
  async function audit(request, signal, progress) {
    const target = parseTarget(request.url, deps.currentUrl());
    if (target === "no_page") return { kind: "no_page" };
    if (target === void 0) return { kind: "invalid_url" };
    const outside = !deps.isConfiguredOrigin(target.origin);
    if (outside && !(await deps.inspectTarget(target)).allowed) {
      return { kind: "blocked", message: "The address is local, private or internal." };
    }
    const session = outside ? deps.anonymousSession() : deps.paneSession;
    const filterEverything = outside;
    if (outside) await session.clearStorageData();
    const refusals = [];
    const remember = (url, reason) => {
      refusals.push({ url: shortUrl(url), reason });
      if (refusals.length > 10) refusals.shift();
    };
    const win = deps.createWindow({
      show: false,
      width: WINDOW_WIDTH,
      height: WINDOW_HEIGHT,
      webPreferences: {
        session,
        sandbox: true,
        offscreen: true,
        backgroundThrottling: false,
        contextIsolation: true,
        nodeIntegration: false,
        webSecurity: true
      }
    });
    const windowId = win.webContents.id;
    win.webContents.setFrameRate(30);
    win.webContents.setWindowOpenHandler(() => ({ action: "deny" }));
    win.webContents.setWebRTCIPHandlingPolicy("disable_non_proxied_udp");
    const isAuditRequest = (webContentsId) => filterEverything || webContentsId === void 0 || webContentsId === windowId;
    const requestFilter = (details, callback) => {
      if (!isAuditRequest(details.webContentsId)) {
        callback({});
        return;
      }
      void inspectAuditRequest(details.url, deps).then((verdict) => {
        if (verdict.allowed) callback({});
        else {
          remember(details.url, verdict.reason);
          callback({ cancel: true });
        }
      });
    };
    session.webRequest.onBeforeRequest(requestFilter);
    session.setPermissionRequestHandler((contents, _permission, callback) => {
      callback(contents.id !== windowId);
    });
    session.setPermissionCheckHandler((contents) => contents?.id !== windowId);
    const stopRefusedNavigation = (url) => {
      void inspectAuditRequest(url, deps).then((verdict) => {
        if (verdict.allowed) return;
        remember(url, verdict.reason);
        if (!win.isDestroyed()) win.webContents.stop();
      });
    };
    const onWillNavigate = (_event, url) => stopRefusedNavigation(url);
    const onWillRedirect = (event, url) => {
      void inspectAuditRequest(url, deps).then((verdict) => {
        if (verdict.allowed) return;
        remember(url, verdict.reason);
        event.preventDefault();
      });
    };
    win.webContents.on("will-navigate", onWillNavigate);
    win.webContents.on("will-redirect", onWillRedirect);
    let transport;
    let browser;
    const work = (async () => {
      const url = target.href;
      let loadTimer;
      try {
        await Promise.race([
          win.loadURL(url),
          new Promise((_, reject) => {
            loadTimer = setTimeout(
              () => reject(new Error("The page did not load in time.")),
              PAGE_LOAD_TIMEOUT_MS
            );
            loadTimer.unref();
          })
        ]);
      } finally {
        if (loadTimer !== void 0) clearTimeout(loadTimer);
      }
      progress?.("Loading tools");
      const lighthouse = (await import("lighthouse")).default;
      const puppeteer = await import("puppeteer-core");
      progress?.("Auditing the page");
      transport = new DebuggerTransport(win.webContents.debugger, {
        title: win.webContents.getTitle(),
        url: win.webContents.getURL()
      });
      browser = await puppeteer.connect({ transport, defaultViewport: null });
      const pageTarget = await browser.waitForTarget(
        (t) => t.type() === puppeteer.TargetType.PAGE,
        { timeout: 1e4 }
      );
      const page = await pageTarget.page();
      if (page === null) return { kind: "failed", message: "The audit page could not be opened." };
      const desktop = request.formFactor === "desktop";
      const config = desktop ? (await import("lighthouse/core/config/desktop-config.js")).default : void 0;
      const result = await lighthouse(
        win.webContents.getURL(),
        { output: "json", logLevel: "error", onlyCategories: [...request.categories] },
        config,
        page
      );
      if (result === void 0)
        return { kind: "failed", message: "Lighthouse returned no result." };
      const lhr = result.lhr;
      const scores = request.categories.map((category) => ({
        category,
        score: lhr.categories[category]?.score ?? null
      }));
      const failures = lighthouseFailures(lhr, request.categories);
      return {
        kind: "report",
        url,
        formFactor: request.formFactor,
        scores,
        failures,
        ...lhr.runtimeError?.message === void 0 ? {} : { runtimeError: lhr.runtimeError.message }
      };
    })();
    let timer;
    const timeout = new Promise((resolve) => {
      timer = setTimeout(() => resolve("timeout"), timeoutMs);
      timer.unref();
    });
    try {
      const raced = await Promise.race([work, timeout, sleepUntilAborted(signal)]);
      if (raced === "timeout") return { kind: "timeout" };
      if (raced === "cancelled") return { kind: "cancelled" };
      return raced;
    } catch (error) {
      const refusal = refusals.at(-1);
      if (refusal !== void 0) {
        const documentRefused = refusals.some((item) => item.url === shortUrl(target.href));
        return {
          kind: documentRefused ? "blocked" : "failed",
          message: `A request to ${refusal.url} was refused because ${refusal.reason}`
        };
      }
      const message = error instanceof Error ? error.message : String(error);
      deps.logger?.warn("PAGE_AUDIT_FAILED");
      return { kind: "failed", message };
    } finally {
      if (timer !== void 0) clearTimeout(timer);
      transport?.close();
      if (!win.isDestroyed()) win.destroy();
      try {
        await browser?.disconnect();
      } catch {
      }
      work.catch(() => void 0);
      session.webRequest.onBeforeRequest(null);
      session.setPermissionRequestHandler(null);
      session.setPermissionCheckHandler(null);
    }
  }
  return (request, signal, progress) => {
    if (accepted > PAGE_AUDIT_MAX_QUEUED) {
      return Promise.resolve({
        kind: "failed",
        message: "An audit is already running, and the queue is full. Try again when it finishes"
      });
    }
    accepted += 1;
    const run = queue.then(
      () => audit(request, signal, progress),
      () => audit(request, signal, progress)
    );
    const settled = run.catch(() => ({ kind: "failed" })).finally(() => {
      accepted -= 1;
    });
    queue = settled;
    return settled;
  };
}

// src/addons/page-audit/index.ts
var apiVersion = 1;
function createPageAuditRunner(deps) {
  return createPageAudit(deps);
}
export {
  apiVersion,
  createPageAuditRunner
};
